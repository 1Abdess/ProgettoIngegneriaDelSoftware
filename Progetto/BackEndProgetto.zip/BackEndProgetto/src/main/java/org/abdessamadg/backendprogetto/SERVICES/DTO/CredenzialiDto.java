package org.abdessamadg.backendprogetto.SERVICES.DTO;

public record CredenzialiDto (String codiceFiscale, String password) {
}
