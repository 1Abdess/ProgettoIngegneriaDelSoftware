package org.abdessamadg.backendprogetto.SERVICES.DTO;

public record ErrorDto(String message) {
}