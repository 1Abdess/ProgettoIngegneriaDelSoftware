package org.abdessamadg.backendprogetto.SERVICES.DTO;

/*
    Uso un record Java per rappresentare un messaggio di errore.
*/

public record ErrorDto(String message) {
}