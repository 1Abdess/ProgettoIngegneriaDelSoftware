package org.abdessamadg.backendprogetto.SERVICES.CONFIG;

public class AuthProvider {
}
