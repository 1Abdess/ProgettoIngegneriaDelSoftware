package org.abdessamadg.backendprogetto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndProgettoApplicationTests {

    @Test
    void contextLoads() {
    }

}
